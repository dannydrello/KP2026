
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, Award, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const AboutPage = () => {
  const values = [
    {
      icon: Heart,
      title: 'Fresh Ingredients',
      description: 'We source only the finest, freshest ingredients from local suppliers to ensure every pastry is of the highest quality.'
    },
    {
      icon: Award,
      title: 'Handmade Quality',
      description: 'Every item is crafted by hand with traditional techniques passed down through generations of master bakers.'
    },
    {
      icon: Users,
      title: 'Customer Satisfaction',
      description: 'Your happiness is our priority. We go above and beyond to create memorable experiences with every order.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>{`About Kitchen Pastries - Always Passionate About your cake`}</title>
        <meta name="description" content="Learn about Kitchen Pastries' story, our commitment to quality, and our passion for creating the finest handcrafted baked goods." />
      </Helmet>

      <div className="min-h-screen">
        <Header />

        {/* Hero Section */}
        <section className="relative pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              <p className="text-xl text-muted-foreground leading-relaxed">
                A passion for baking that started in a small kitchen and grew into a beloved community bakery
              </p>
            </motion.div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <img
                  src="https://images.unsplash.com/photo-1580640663388-188ec9509935"
                  alt="Professional bakery kitchen with fresh pastries"
                  className="rounded-xl shadow-soft-xl w-full h-[500px] object-cover"
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="space-y-6"
              >
                <h2 className="text-4xl font-bold text-foreground">Where It All Began</h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Kitchen Pastries was born from a simple dream: to bring the warmth and comfort of homemade baked goods to our community. What started as a small home kitchen operation in 2015 has blossomed into a thriving bakery that serves hundreds of happy customers every week.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Our founder, Maria Santos, learned the art of baking from her grandmother in a small village in France. She brought those time-honored recipes and techniques to create a bakery that feels like home - where every croissant is perfectly flaky, every cake is moist and delicious, and every customer is treated like family.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Today, we continue to honor those traditions while innovating with new flavors and creations. Every morning, our team of passionate bakers arrives before dawn to ensure that when you walk through our doors, you're greeted with the irresistible aroma of fresh-baked goodness.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Mission & Values Section */}
        <section className="py-16 bg-secondary">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">Our Mission & Values</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                The principles that guide everything we do
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="rounded-xl shadow-soft-lg hover:shadow-soft-xl transition-smooth hover:scale-105 border-border bg-background h-full">
                    <CardContent className="p-8 text-center">
                      <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-6">
                        <value.icon className="w-8 h-8 text-primary-foreground" />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground mb-4">{value.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Baking Process Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="space-y-6 order-2 lg:order-1"
              >
                <h2 className="text-4xl font-bold text-foreground">Crafted with Care</h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Every pastry that leaves our kitchen is the result of meticulous attention to detail and a genuine love for the craft. Our bakers start their day at 4 AM, carefully measuring ingredients, kneading dough, and monitoring temperatures to ensure perfection.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  We believe in the slow food movement - taking the time to let our dough rise naturally, allowing flavors to develop fully, and never rushing the process. This dedication to quality is what makes our pastries stand out.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  From our signature croissants with their 27 delicate layers to our rich chocolate cakes made with premium Belgian chocolate, every item reflects our commitment to excellence and our passion for bringing joy through food.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="order-1 lg:order-2"
              >
                <img
                  src="https://images.unsplash.com/photo-1703607888337-aae6d77b3d83"
                  alt="Baker carefully preparing fresh pastries in professional kitchen"
                  className="rounded-xl shadow-soft-xl w-full h-[500px] object-cover"
                />
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default AboutPage;
