import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ShoppingCart, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useCart } from '@/components/CartContext.jsx';
import { useToast } from '@/hooks/use-toast';

const MenuPage = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [quantities, setQuantities] = useState({});
  const { addToCart } = useCart();
  const { toast } = useToast();

  const products = [
    // Existing 12 products
    {
      id: 1,
      name: 'Cheesecake slice',
      category: 'Cake',
      price: '₦6000',
      description: 'Buttery, flaky layers of perfection baked fresh every morning',
      image: 'https://images.unsplash.com/photo-1623843399237-35c37d194feb'
    },
    {
      id: 2,
      name: 'Single Iced cupcakes',
      category: 'Cakes',
      price: '₦1900',
      description: 'Rich, moist iced cake',
      image: 'https://images.unsplash.com/photo-1573036714088-9d3ff975fd3c'
    },
    {
      id: 3,
      name: 'Hotdog waffle',
      category: 'Pastry',
      price: '₦750',
      description: 'Sweet, soft donuts with a perfect glaze, made fresh daily',
      image: 'https://images.unsplash.com/photo-1517433367423-c7e5b0f35086'
    },
    {
      id: 4,
      name: 'Childrens pastry party bag',
      category: 'Pastry',
      price: '₦2000',
      description: '2 Ghana buns , 1 hotdog waffle and party Meatpie',
      image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb'
    },
    {
      id: 5,
      name: 'Cake mail; MR TEMPTATION',
      category: 'Cake',
      price: '₦9850',
      description: 'Flavors; carrot , marble, plantain',
      image: 'https://images.unsplash.com/photo-1648328744880-a421f0cc1b73'
    },
    {
      id: 6,
      name: 'Cake mail; MR ORIGINAL',
      category: 'Cakes',
      price: '₦9850',
      description: 'Sig Vanilla, Red velvet and chocolate',
      image: 'https://images.unsplash.com/photo-1688430885182-f0cca3d04910'
    },
    {
      id: 7,
      name: 'White Chocolate Oat Cookie',
      category: 'Cookies',
      price: '₦2750',
      description: 'Dozen of chewy cookies loaded with premium chocolate chips',
      image: 'https://images.unsplash.com/photo-1517433367423-c7e5b0f35086'
    },
    {
      id: 8,
      name: 'Chicken Tortilla wrap',
      category: 'Snack',
      price: '₦6000',
      description: 'Chicken Tortilla wrap',
      image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb'
    },
    {
      id: 9,
      name: 'Tea Premium Breakfast Tray',
      category: 'Special Orders',
      price: '₦100000',
      description: 'Waffles, Sandwitch, Cake, Egg, Drinks etc',
      image: 'https://images.unsplash.com/photo-1573036714088-9d3ff975fd3c'
    },
    {
      id: 10,
      name: 'Yougurt',
      category: 'Drinks',
      price: '₦1800',
      description: 'vanilla , Strawberry , Banana',
      image: 'https://images.unsplash.com/photo-1688430885182-f0cca3d04910'
    },
    {
      id: 11,
      name: 'Chicken Sandwitch',
      category: 'Snack',
      price: '₦2400',
      description: 'Chicken sandwitch',
      image: 'https://images.unsplash.com/photo-1648328744880-a421f0cc1b73'
    },
    {
      id: 12,
      name: 'Milkshake',
      category: 'Drinks',
      price: '₦2950',
      description: 'Chill sweet and healthy Milkshake',
      image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb'
    },
    
    // BREAD & ROLLS (IDs 13-18)
    { id: 13, name: 'Bannana Loaf', category: 'Bread & Rolls', price: '₦3950', description: 'Super-moist, homemade banana bread packed with ripe bananas and warm spices. A comforting, timeless treat perfect with coffee.', image: 'https://images.unsplash.com/photo-1552302094-91d111d7aad0' },
    { id: 14, name: 'Brownie cup', category: 'Chin Chin & Snacks', price: '₦3000', description: 'Sweet brownies', image: 'https://images.unsplash.com/photo-1620327087153-6e9091133ea7' },
    { id: 15, name: 'Gizodo pack', category: 'Chin Chin & Snacks', price: '₦11,900', description: 'Nutritious whole wheat bread', image: 'https://images.unsplash.com/photo-1700659392748-68904081f748' },
    { id: 16, name: 'Dinner Rolls', category: 'Bread & Rolls', price: '₦800', description: 'Pack of 6 soft, buttery rolls', image: 'https://images.unsplash.com/photo-1698483919189-28805b3f8ee8' },
    { id: 17, name: 'Baguette', category: 'Bread & Rolls', price: '₦1100', description: 'Crispy French-style baguette', image: 'https://images.unsplash.com/photo-1668709461437-dab5781e6a2c' },
    { id: 18, name: 'Focaccia Bread', category: 'Bread & Rolls', price: '₦1300', description: 'Olive oil infused Italian bread', image: 'https://images.unsplash.com/photo-1552302094-91d111d7aad0' },

    // Special orders (IDs 19-24)
    { id: 19, name: 'Silver Premium Breakfst tray', category: 'Special orders', price: '₦60000', description: 'Sandwitch, drinks, waffles etc', image: 'https://images.unsplash.com/photo-1533176360851-2c388730a009' },
    { id: 20, name: 'Diamond Premium Breakfast tray', category: 'Special orders', price: '₦150000', description: 'Sandwitch, drinks, waffles, puffs, eggs etc', image: 'https://images.unsplash.com/photo-1464375305692-5f97ca7e2c81' },
    { id: 21, name: 'Cake mail; CHIEFs Delight', category: 'Special orders', price: '₦7000', description: 'Flavors; orange, cookies n cream, Green Velvet', image: 'https://images.unsplash.com/photo-1600636252478-e88584ef3d9f' },
    { id: 22, name: 'Full bird chops box', category: 'Special orders', price: '₦45000', description: 'Full bird chops box', image: 'https://images.unsplash.com/photo-1686515266396-080c4939e6b4' },
    { id: 23, name: 'Half bird chops box', category: 'Special orders', price: '₦29000', description: 'Half bird chops box', image: 'https://images.unsplash.com/photo-1616826964727-ec5243916254' },
    { id: 24, name: 'Christmas Day pastry box', category: 'Special orders', price: '₦48950', description: 'spingrolls, meatpies etc', image: 'https://images.unsplash.com/photo-1533176360851-2c388730a009' },

    // MEAT PIES & SAVORY (IDs 25-30)
    { id: 25, name: 'Christmas day salad tray', category: 'Special orders', price: '₦19900', description: 'Flaky pastry with seasoned beef filling', image: 'https://images.unsplash.com/photo-1464375305692-5f97ca7e2c81' },
    { id: 26, name: 'Individual Premium breakfast box', category: 'Special orders', price: '₦22500', description: 'Glorious breakfast with cake, apple etc', image: 'https://images.unsplash.com/photo-1600636252478-e88584ef3d9f' },
    { id: 27, name: 'Box of peppered chicken', category: 'Special orders', price: '₦31,500', description: '10 chicken drumsticks with 2 eggs', image: 'https://images.unsplash.com/photo-1686515266396-080c4939e6b4' },
    { id: 28, name: 'Drumstick chicken salad', category: 'Special orders', price: '₦5000', description: 'Pork sausage wrapped in pastry', image: 'https://images.unsplash.com/photo-1616826964727-ec5243916254' },
    { id: 29, name: 'Shredded chicken salad', category: 'Special orders', price: '₦6000', description: 'ham filling shredded chicken salad', image: 'https://images.unsplash.com/photo-1533176360851-2c388730a009' },
    { id: 30, name: 'Spinach & Feta Pie', category: 'Meat Pies & Savory', price: '₦850', description: 'Greek-inspired savory pie', image: 'https://images.unsplash.com/photo-1464375305692-5f97ca7e2c81' },

    // CHIN CHIN & SNACKS (IDs 31-36)
    { id: 31, name: 'Chin Chin painter', category: 'Chin Chin & Snacks', price: '₦18000', description: 'Crispy fried snack, painter', image: 'https://images.unsplash.com/photo-1584972990783-18464a2ae653' },
    { id: 32, name: 'Creamy puff pots', category: 'Chin Chin & Snacks', price: '₦1500', description: 'creamy puffs', image: 'https://images.unsplash.com/photo-1679710552994-5431157ebc07' },
    { id: 33, name: 'Mini Sausage pot', category: 'Chin Chin & Snacks', price: '₦1450', description: 'mini sausage pot', image: 'https://images.unsplash.com/photo-1612906307056-b49d3f311b9d' },
    { id: 34, name: 'Fishroll', category: 'Chin Chin & Snacks', price: '₦950', description: 'Very nice fishroll', image: 'https://images.unsplash.com/photo-1598839950984-034f6dc7b495' },
    { id: 35, name: 'Christmas day puffs', category: 'Chin Chin & Snacks', price: '₦100', description: 'variety puffs .. plain , chocolate , coconut', image: 'https://images.unsplash.com/photo-1598839950900-cb950a10bc4d' },
    { id: 36, name: 'Ghana buns', category: 'Chin Chin & Snacks', price: '₦850', description: 'soft and tasty ghana buns', image: 'https://images.unsplash.com/photo-1584972990783-18464a2ae653' },

    // DONUTS (IDs 37-42)
    { id: 37, name: 'Fresh cold pressed juice', category: 'Drinks', price: '₦2000', description: 'fresh cold juice, zobo (1200)', image: 'https://images.unsplash.com/photo-1648328744880-a421f0cc1b73' },
    { id: 38, name: 'Crispy chicken burger', category: 'Chin Chin & Snacks', price: '₦5000', description: 'Crispy chicken burger', image: 'https://images.unsplash.com/photo-1581323864255-e272b5fecab5' },
    { id: 39, name: 'Greek Yogurt parfait', category: 'Drinks', price: '₦3500', description: 'Greek Yogurt', image: 'https://images.unsplash.com/photo-1702264893900-3fc04fe4a22e' },
    { id: 40, name: 'Jelly-Filled Donut', category: 'Donuts', price: '₦550', description: 'Fruity jelly center', image: 'https://images.unsplash.com/photo-1504674138570-5fe6671ec5ed' },
    { id: 41, name: 'Boston Cream Donut', category: 'Donuts', price: '₦600', description: 'Cream and chocolate topping', image: 'https://images.unsplash.com/photo-1649506174961-fd0a59c3f6fa' },
    { id: 42, name: 'Cinnamon Sugar Donut', category: 'Donuts', price: '₦480', description: 'Warm cinnamon coating', image: 'https://images.unsplash.com/photo-1648328744880-a421f0cc1b73' },

    // COOKIES (IDs 43-48)
    { id: 43, name: 'Large chin chin', category: 'Chin Chin & Snacks', price: '₦5,500', description: 'Pack of 6 classic cookies', image: 'https://images.unsplash.com/photo-1584972990783-18464a2ae653' },
    { id: 44, name: 'Scotch Egg (x4)', category: 'Chin Chin & Snacks', price: '₦7000', description: 'Melt-in-mouth scotch egg', image: 'https://images.unsplash.com/photo-1679710552994-5431157ebc07' },
    { id: 45, name: 'popcorn', category: 'Chin Chin & Snacks', price: '₦650', description: 'Sweetened/salted sweetened', image: 'https://images.unsplash.com/photo-1612906307056-b49d3f311b9d' },
    { id: 46, name: 'Extra healty premium breakfast tray', category: 'Special orders', price: '₦82000', description: 'Extra healty premium breakfast tray', image: 'https://images.unsplash.com/photo-1598839950984-034f6dc7b495' },
    { id: 47, name: 'Fresh Greek Yougurt', category: 'Drinks', price: '₦5,500', description: 'Crunchy almond delight', image: 'https://images.unsplash.com/photo-1598839950900-cb950a10bc4d' },
    { id: 48, name: 'Coconut Cookies', category: 'Cookies', price: '₦650', description: 'Toasted coconut cookies', image: 'https://images.unsplash.com/photo-1584972990783-18464a2ae653' },

    // CUPCAKES & SMALL CAKES (IDs 49-54)
    { id: 49, name: 'Cake in a cup', category: 'Cupcakes & Small Cakes', price: '₦2200', description: 'vanilla , Red velvet , chocolate , malted milk , strawberry', image: 'https://images.unsplash.com/photo-1583087244248-07c7ebb84070' },
    { id: 50, name: 'Jumbo cupcake', category: 'Cupcakes & Small Cakes', price: '₦1300', description: 'red velvet , vanilla , chocolate , cookies n crème , strawberry , malted milk', image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb' },
    { id: 51, name: 'Trple delight bento cake', category: 'Cupcakes & Small Cakes', price: '₦5,500', description: 'All flavours available', image: 'https://images.unsplash.com/photo-1537439532841-f79e1d12df21' },
    { id: 52, name: 'Large Fresh Greek Yougurt', category: 'Drinks', price: '₦9000', description: 'Elegant red velvet', image: 'https://images.unsplash.com/photo-1698126216566-8fff1a16c742' },
    { id: 53, name: 'Cake in a cup', category: 'Cupcakes & Small Cakes', price: '₦1750', description: 'Moist cream cake', image: 'https://images.unsplash.com/photo-1578180921031-ae4f47bd2042' },
    { id: 54, name: 'Chocolate Fudge Cupcake', category: 'Cupcakes & Small Cakes', price: '₦1800', description: 'Rich chocolate indulgence', image: 'https://images.unsplash.com/photo-1583087244248-07c7ebb84070' },

    // LARGE CAKES (IDs 55-60)
    { id: 55, name: 'Triple delight naked christmas cake', category: 'Large Cakes', price: '₦30000', description: 'Light and fluffy sweet cake', image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb' },
    { id: 56, name: '6" tripple delight naked cake', category: 'Large Cakes', price: '₦16000', description: 'Decadent chocolate layer cake', image: 'https://images.unsplash.com/photo-1537439532841-f79e1d12df21' },
    { id: 57, name: 'Carrot Cake', category: 'Large Cakes', price: '₦5500', description: 'Moist carrot with cream cheese frosting', image: 'https://images.unsplash.com/photo-1698126216566-8fff1a16c742' },
    { id: 58, name: 'Red Velvet Cake', category: 'Large Cakes', price: '₦6500', description: 'Classic red velvet with cream cheese', image: 'https://images.unsplash.com/photo-1578180921031-ae4f47bd2042' },
    { id: 59, name: 'Lemon Drizzle Cake', category: 'Large Cakes', price: '₦5000', description: 'Tangy lemon with glaze', image: 'https://images.unsplash.com/photo-1583087244248-07c7ebb84070' },
    { id: 60, name: 'Fruit Cake', category: 'Large Cakes', price: '₦6000', description: 'Traditional fruit cake with dried fruits', image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb' },

    // SPECIALTY CAKES (IDs 61-66)
    { id: 61, name: 'Wedding Cake', category: 'Specialty Cakes', price: '₦15000', description: '3-tier elegant wedding cake', image: 'https://images.unsplash.com/photo-1537439532841-f79e1d12df21' },
    { id: 62, name: 'Birthday Cake', category: 'Specialty Cakes', price: '₦8000', description: 'Customizable birthday cake', image: 'https://images.unsplash.com/photo-1698126216566-8fff1a16c742' },
    { id: 63, name: 'Cheesecake', category: 'Specialty Cakes', price: '₦7000', description: 'Creamy New York style cheesecake', image: 'https://images.unsplash.com/photo-1578180921031-ae4f47bd2042' },
    { id: 64, name: 'Black Forest Cake', category: 'Specialty Cakes', price: '₦7500', description: 'Chocolate with cherries', image: 'https://images.unsplash.com/photo-1583087244248-07c7ebb84070' },
    { id: 65, name: 'Tiramisu Cake', category: 'Specialty Cakes', price: '₦6500', description: 'Italian coffee-flavored cake', image: 'https://images.unsplash.com/photo-1690584177253-58e128f05ceb' },
    { id: 66, name: 'Chocolate Mousse Cake', category: 'Specialty Cakes', price: '₦7000', description: 'Light and airy mousse', image: 'https://images.unsplash.com/photo-1537439532841-f79e1d12df21' },

    // PASTRIES & TARTS (IDs 67-70)
    { id: 67, name: 'Croissant', category: 'Pastries & Tarts', price: '₦3000', description: 'Buttery French croissant', image: 'https://images.unsplash.com/photo-1648328744880-a421f0cc1b73' },
    { id: 68, name: 'Box of Springrolls (10)', category: 'Pastries & Tarts', price: '₦3500', description: 'Sweet springrolls', image: 'https://images.unsplash.com/photo-1581323864255-e272b5fecab5' },
    { id: 69, name: 'Club Croissant', category: 'Pastries & Tarts', price: '₦5000', description: 'French croissant with extra veggies', image: 'https://images.unsplash.com/photo-1702264893900-3fc04fe4a22e' },
    { id: 70, name: 'Pot of Samosas (10)', category: 'Pastries & Tarts', price: '₦4000', description: 'Sweet mouth-watery samosas', image: 'https://images.unsplash.com/photo-1504674138570-5fe6671ec5ed' }
  ];

  // Dynamically generate categories from products array
  const categories = ['all', ...new Set(products.map(p => p.category))];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const handleQuantityChange = (id, delta) => {
    setQuantities(prev => {
      const current = prev[id] || 1;
      const next = Math.max(1, Math.min(99, current + delta));
      return { ...prev, [id]: next };
    });
  };

  const handleAddToCart = (product) => {
    const qty = quantities[product.id] || 1;
    addToCart(product, qty);
    toast({
      title: "Added to Cart",
      description: `Added ${qty} ${product.name} to your cart.`,
    });
    // Reset quantity after adding
    setQuantities(prev => ({ ...prev, [product.id]: 1 }));
  };

  return (
    <>
      <Helmet>
        <title>{`Menu - Kitchen Pastries - Always Passionate About your cake`}</title>
        <meta name="description" content="Browse our full menu of handcrafted pastries, cakes, bread, cookies, and custom orders. Fresh baked goods made daily with premium ingredients." />
      </Helmet>

      <div className="min-h-screen">
        <Header />

        {/* Hero Section */}
        <section className="relative pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              <p className="text-xl text-muted-foreground leading-relaxed">
                Explore our delicious selection of handcrafted pastries, baked fresh every day
              </p>
            </motion.div>
          </div>
        </section>

        {/* Menu Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            {/* Category Filter */}
            <div className="mb-12 overflow-x-auto pb-4">
              <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full min-w-max">
                <TabsList className="flex flex-wrap gap-2 bg-secondary p-2 rounded-xl h-auto justify-center">
                  {categories.map((category) => (
                    <TabsTrigger
                      key={category}
                      value={category}
                      className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-smooth capitalize px-4 py-2"
                    >
                      {category === 'all' ? 'All Items' : category}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: (index % 10) * 0.05 }}
                >
                  <Card className="overflow-hidden rounded-xl shadow-soft-lg hover:shadow-soft-xl transition-all duration-300 ease-in-out hover:scale-[1.03] hover:bg-[#FFC600] border-border h-full flex flex-col group">
                    <div className="relative h-64 overflow-hidden">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover transition-smooth group-hover:scale-110"
                      />
                      <div className="absolute top-4 right-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold shadow-soft">
                        {product.category}
                      </div>
                    </div>
                    <CardContent className="p-6 flex-1 flex flex-col">
                      <h3 className="text-xl font-bold text-foreground group-hover:text-gray-900 mb-2 transition-colors">{product.name}</h3>
                      <p className="text-sm text-muted-foreground group-hover:text-gray-800 mb-4 flex-1 transition-colors">{product.description}</p>
                      
                      <div className="flex flex-col gap-4 mt-auto">
                        <span className="text-2xl font-bold text-primary group-hover:text-gray-900 transition-colors">{product.price}</span>
                        
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center border border-border rounded-lg overflow-hidden bg-background/80 backdrop-blur-sm">
                            <button
                              onClick={() => handleQuantityChange(product.id, -1)}
                              className="p-2 hover:bg-secondary transition-smooth text-foreground"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center font-medium text-foreground">
                              {quantities[product.id] || 1}
                            </span>
                            <button
                              onClick={() => handleQuantityChange(product.id, 1)}
                              className="p-2 hover:bg-secondary transition-smooth text-foreground"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                          
                          <Button 
                            onClick={() => handleAddToCart(product)}
                            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground shadow-soft transition-smooth"
                          >
                            <ShoppingCart className="mr-2 w-4 h-4" />
                            Add
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-16">
                <p className="text-xl text-muted-foreground">No items found in this category.</p>
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default MenuPage;