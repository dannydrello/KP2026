
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ImageModal from '@/components/ImageModal.jsx';

const galleryImages = [
  {
    id: 1,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/f112dc38f5af5f56dfb0e54f622108e2.jpg',
    alt: 'Love cake with red ribbon topper, chocolate drip, cream frosting, red rose, and gold chocolate'
  },
  {
    id: 2,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/84e02410309e99cf292f40c53fc53ab3.jpg',
    alt: 'Elegant two-tier cake with gold frame photo topper, gold bow, black glitter jacket, marble base, gold decorative balls'
  },
  {
    id: 3,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/e8f399f67641a4ee8d064bc9e6f0692b.jpg',
    alt: 'Colorful multi-tier celebration cake with photo topper, red balloon, yellow flowers, gold accents'
  },
  {
    id: 4,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/0afb8b29e985f2025e09b49bb320f99e.jpg',
    alt: 'White and gold elegant cake with religious cross decorations, purple ribbon, white flowers'
  },
  {
    id: 5,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/973bc84468ebc3fc08c0403e9264d7bf.jpg',
    alt: 'Chocolate bark textured cake with red berries, white flowers, gold bottle topper'
  },
  {
    id: 6,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/2051c499aa4becf7cbc536ec0df7528e.jpg',
    alt: 'Pink fluffy teddy bear cake with white bow, gold number 3'
  },
  {
    id: 7,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/f44f749bb988680f652fc57a7874802b.jpg',
    alt: 'Chocolate textured cake with red rose, red berries, yellow fern, gold topper'
  },
  {
    id: 8,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/bb6e2a687e8b87e8666c4f2497ecd460.jpg',
    alt: 'Colorful pencil and graduation cap cake with school logo, multicolor design'
  },
  {
    id: 9,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/e7f12b00c799d0df00315fcdc92c7144.jpg',
    alt: 'Chocolate cake with red rose, red berries, gold Happy Birthday topper'
  },
  {
    id: 10,
    src: 'https://horizons-cdn.hostinger.com/af6267a3-879e-4e3c-a1ed-86471b79742c/fac7934480806303477a46dc1662f44a.jpg',
    alt: 'Red and gold layered cake with decorative elements'
  }
];

const GalleryPage = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openModal = (index) => {
    setCurrentIndex(index);
    setModalOpen(true);
  };

  const handleNavigate = (direction) => {
    if (direction === 'prev') {
      setCurrentIndex((prev) => (prev === 0 ? galleryImages.length - 1 : prev - 1));
    } else {
      setCurrentIndex((prev) => (prev === galleryImages.length - 1 ? 0 : prev + 1));
    }
  };

  return (
    <>
      <Helmet>
        <title>{`Gallery - Custom Cake Creations`}</title>
        <meta name="description" content="Explore our gallery of custom cake creations, featuring elegant designs, colorful celebrations, and delicious treats." />
      </Helmet>

      <div className="min-h-screen bg-[#FFF8F0] flex flex-col">
        <Header />

        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-[#3D2817] text-white text-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-[#FCD34D]">
              Our Custom Cake Creations
            </h1>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed">
              Browse through our portfolio of handcrafted, beautifully designed cakes. Each creation is a unique masterpiece tailored to make your special moments unforgettable.
            </p>
          </motion.div>
        </section>

        {/* Gallery Grid */}
        <section className="py-16 flex-grow">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
              {galleryImages.map((image, index) => (
                <motion.div
                  key={image.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="break-inside-avoid cursor-pointer group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300"
                  onClick={() => openModal(index)}
                >
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-500 ease-in-out"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
                    <span className="opacity-0 group-hover:opacity-100 text-white font-medium bg-black/50 px-4 py-2 rounded-full transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                      View Full Size
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />

        <ImageModal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          images={galleryImages}
          currentIndex={currentIndex}
          onNavigate={handleNavigate}
        />
      </div>
    </>
  );
};

export default GalleryPage;
