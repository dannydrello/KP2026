
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageCircle, ShoppingCart, Package, Edit2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/components/CartContext.jsx';

const OrderPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { cartItems, subtotal, tax, total, clearCart } = useCart();
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    deliveryOption: 'pickup',
    address: ''
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleWhatsAppOrder = () => {
    if (cartItems.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your cart before ordering.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.name || !formData.phone || (formData.deliveryOption === 'delivery' && !formData.address)) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    const deliveryText = formData.deliveryOption === 'delivery' ? 'Delivery' : 'Pickup';
    
    let itemsText = cartItems.map(item => `- ${item.quantity}x ${item.name} (${item.price})`).join('\n');

    const message = `Hello! I'd like to place an order:

Name: ${formData.name}
Phone: ${formData.phone}
Email: ${formData.email || 'Not provided'}
Option: ${deliveryText}
${formData.deliveryOption === 'delivery' ? `Address: ${formData.address}\n` : ''}
Order Details:
${itemsText}

Subtotal: $${subtotal}
Tax: $${tax}
Total: $${total}

Thank you!`;

    const whatsappUrl = `https://wa.me/15551234567?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    
    toast({
      title: "Order placed successfully!",
      description: "You are being redirected to WhatsApp to complete your order.",
    });
    
    clearCart();
    navigate('/');
  };

  return (
    <>
      <Helmet>
        <title>{`Order - Kitchen Pastries - Always Passionate About your cake`}</title>
        <meta name="description" content="Complete your order for fresh pastries." />
      </Helmet>

      <div className="min-h-screen">
        <Header />

        {/* Hero Section */}
        <section className="relative pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              <p className="text-xl text-muted-foreground leading-relaxed">
                Complete your details to place your order
              </p>
            </motion.div>
          </div>
        </section>

        {/* Order Form Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
            {cartItems.length === 0 ? (
              <div className="text-center py-16 bg-secondary rounded-xl shadow-soft">
                <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h2 className="text-2xl font-semibold text-foreground mb-4">Your cart is empty</h2>
                <p className="text-muted-foreground mb-8">Add some delicious pastries to your cart before checking out.</p>
                <Link to="/menu">
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-soft-lg transition-smooth hover:scale-105">
                    Browse Menu
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Order Form */}
                <div className="lg:col-span-2">
                  <Card className="rounded-xl shadow-soft-lg border-border">
                    <CardHeader>
                      <CardTitle className="text-2xl font-bold text-foreground flex items-center">
                        <Package className="mr-2 w-6 h-6 text-primary" />
                        Delivery Details
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Customer Information */}
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-foreground font-semibold">
                            Full Name *
                          </Label>
                          <Input
                            id="name"
                            placeholder="John Doe"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            className="bg-background text-foreground border-border"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="phone" className="text-foreground font-semibold">
                            Phone Number *
                          </Label>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+1 (555) 123-4567"
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            className="bg-background text-foreground border-border"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-foreground font-semibold">
                            Email Address
                          </Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="john@example.com"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            className="bg-background text-foreground border-border"
                          />
                        </div>
                      </div>

                      {/* Delivery Options */}
                      <div className="space-y-4 pt-4 border-t border-border">
                        <Label className="text-foreground font-semibold">Delivery Option *</Label>
                        <RadioGroup value={formData.deliveryOption} onValueChange={(value) => handleInputChange('deliveryOption', value)}>
                          <div className="flex items-center space-x-3 p-4 rounded-lg border border-border hover:bg-secondary transition-smooth">
                            <RadioGroupItem value="pickup" id="pickup" />
                            <Label htmlFor="pickup" className="flex-1 cursor-pointer text-foreground">
                              <div className="font-semibold">Pickup</div>
                              <div className="text-sm text-muted-foreground">Pick up from our bakery</div>
                            </Label>
                            <Package className="w-5 h-5 text-primary" />
                          </div>
                          <div className="flex items-center space-x-3 p-4 rounded-lg border border-border hover:bg-secondary transition-smooth">
                            <RadioGroupItem value="delivery" id="delivery" />
                            <Label htmlFor="delivery" className="flex-1 cursor-pointer text-foreground">
                              <div className="font-semibold">Delivery</div>
                              <div className="text-sm text-muted-foreground">Delivered to your address</div>
                            </Label>
                            <Package className="w-5 h-5 text-primary" />
                          </div>
                        </RadioGroup>
                      </div>

                      {formData.deliveryOption === 'delivery' && (
                        <div className="space-y-2 pt-4">
                          <Label htmlFor="address" className="text-foreground font-semibold">
                            Delivery Address *
                          </Label>
                          <Input
                            id="address"
                            placeholder="123 Main St, Apt 4B, City, State, ZIP"
                            value={formData.address}
                            onChange={(e) => handleInputChange('address', e.target.value)}
                            className="bg-background text-foreground border-border"
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Order Summary */}
                <div className="lg:col-span-1">
                  <Card className="rounded-xl shadow-soft-lg border-border sticky top-24">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle className="text-2xl font-bold text-foreground">Order Summary</CardTitle>
                      <Link to="/cart" className="text-primary hover:text-primary/80 transition-smooth">
                        <Edit2 className="w-5 h-5" />
                      </Link>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
                        {cartItems.map((item) => (
                          <div key={item.id} className="flex justify-between text-sm">
                            <div className="flex items-start gap-2">
                              <span className="font-semibold text-foreground">{item.quantity}x</span>
                              <span className="text-muted-foreground">{item.name}</span>
                            </div>
                            <span className="font-semibold text-foreground">{item.price}</span>
                          </div>
                        ))}
                      </div>

                      <div className="pt-4 border-t border-border space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Subtotal:</span>
                          <span className="font-semibold text-foreground">${subtotal}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Tax (10%):</span>
                          <span className="font-semibold text-foreground">${tax}</span>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-border">
                        <div className="flex justify-between items-center">
                          <span className="text-lg font-bold text-foreground">Total:</span>
                          <span className="text-3xl font-bold text-primary">${total}</span>
                        </div>
                      </div>

                      <Button
                        onClick={handleWhatsAppOrder}
                        className="w-full bg-[#25D366] hover:bg-[#20BA5A] text-white py-6 text-lg shadow-soft-lg hover:shadow-soft-xl transition-smooth hover:scale-105"
                      >
                        <MessageCircle className="mr-2 w-5 h-5" />
                        Place Order via WhatsApp
                      </Button>

                      <p className="text-xs text-muted-foreground text-center">
                        You'll be redirected to WhatsApp to complete your order
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default OrderPage;
